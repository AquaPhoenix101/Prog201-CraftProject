﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project2_Craft
{
    /// Code framework Grabbed from Janell Baxter - https://github.com/janell-baxter/ProgrammingIICraftDemo
    internal class Workshop
    {

        //player + vendor inventory
        List<Recipe> Recipes = new List<Recipe>();
        public int RecipeNumber;
        public bool addedItem = false;
        Player player = new Player()
        {
            Inventory = new List<Item>
        {
            new Item() {Name="Pair of Lungs", Amount = 1},
            new Item() {Name="Rubber Duck", Amount = 10 }

             }
        };
        Person vendor = new Person()
        {
            Inventory = new List<Item>
        {
            new Item() {Name="Phoenix Feather", Amount = 10},
            new Item() {Name = "Ashes", Amount = 15},
            new Item() {Name = "Bottled Rage", Amount = 5}

             }
        };

        //recipes requirements
        public Workshop()
        {
            SetPlayerName("Anonymous Player");
            Recipes.Add(
                new Recipe()
                {
                    Name = "Potion of Infinite Bouyancy",
                    Description = "Drinking this fills you with air, you will not fly away, we promise.",
                    Amount = 1,
                    Requirements = new List<Item>()
                    {
                        new Item(){Name = "Rubber Duck", Amount = 10},
                        new Item(){Name = "Pair of Lungs", Amount = 1}
                    },

                }
                ) ; 
            Recipes.Add(
                new Recipe()
                {
                    Name = "Potion of The Phoenix",
                    Description = "Drinking this fills you with life. Come back to life once.",
                    Requirements = new List<Item>()
                    {
                        new Item(){Name = "Phoenix Feather", Amount = 1},
                        new Item(){Name = "Ashes", Amount = 5},
                        new Item(){Name = "Bottled Rage", Amount = 2}
                    },

                }                
                );
            Recipes.Add(
                new Recipe()
                {
                    Name = "Potion of Considerable Knowledge",
                    Description = "Drinking this fills you with smarts. You can now read!",
                    Requirements = new List<Item>()
                    {
                        new Item(){Name = "A Book", Amount = 2},
                        new Item(){Name = "Apples", Amount = 5},
                        new Item(){Name = "Teacher's Glasses", Amount = 1}
                    },

                }
                );
            
        }


        //craft outputs
        public string CraftOutput1()
        {
            RecipeNumber = 0;
            CreateNewItem(RecipeNumber);
            string output = "";
            if (addedItem == true)
            {
                player.Inventory.Add(new Item { Name = "Potion of Infinite Buoyancy", Amount = 1, Value = 50 });
                output += "You've obtained a new item!\n";
                output += "Click the button below to continue.";               

            }
            else if (addedItem == false)
            {
                output += "You don't have the required materials...";
            };
            output += "";
            return output;
        }
        public string CraftOutput2()
        {
            RecipeNumber = 1;
            CreateNewItem(RecipeNumber);
            string output = "";
            if (addedItem == true)
            {
                player.Inventory.Add(new Item { Name = "Potion of The Phoenix", Amount = 1, Value = 50 });
                output += "You've obtained a new item!\n";
                output += "Click the button below to continue.";

            }
            else if (addedItem == false)
            {
                output += "You don't have the required materials...";
            };
            output += "";
            return output;
        }
        public string CraftOutput3()
        {
            RecipeNumber = 2;
            CreateNewItem(RecipeNumber);
            string output = "";
            if (addedItem == true)
            {
                player.Inventory.Add(new Item { Name = "Potion of Considerable Knowledge", Amount = 1, Value = 50 });
                output += "You've obtained a new item!\n";
                output += "Click the button below to continue.";

            }
            else if (addedItem == false)
            {
                output += "You don't have the required materials...";
            };
            output += "";
            return output;
        }

        //end craft outputs

        public void CreateNewItem(int recipeNumber)
        {
            addedItem = false;
            foreach (Item r in Recipes[RecipeNumber].Requirements)
            {
                foreach (Item i in player.Inventory)
                {
                    if (r.Name == i.Name)
                    {

                        if (i.Amount >= r.Amount)
                        {
                            addedItem = true;
                            i.Amount -= r.Amount;
                        }
                        else
                        {
                            addedItem = false;
                        }
                    }                    

                }
            }
            
            
        }

        
        public string Trade()
        {
            return "\nTrade is not yet functional.\n";
        }
        public string ShowRecipes()
        {
            string output = "Recipes:\n";
            foreach (Recipe r in Recipes)
            {
                output += $" *{r.ShowRecipeDetails()}\n";
            }
            return output;
        }
        public string ShowInventory(string p)
        {
            Person person = player;
            if (p == "vendor") person = vendor;

            string output = $"Current inventory:\n";
            foreach (Item i in person.Inventory)
            {
                output += $"  * {i.Name} ({i.Amount})\n";
            }
            return output;
        }

        public string ShowPlayerName() => player.Name;
        public string ShowPlayerNameAndMoney() => $"{player.Name} {player.Money.ToString("c")}";
        public void SetPlayerName(string name) { player.Name = name; }

    }
}

